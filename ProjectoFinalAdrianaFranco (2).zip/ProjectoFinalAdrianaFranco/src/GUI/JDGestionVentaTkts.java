/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package GUI;

import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ProyectoFinal.*;
import ProyectoFinal.ContentTXTGestionVentaTkts;

/**
 * Esta clase representa la ventana de gestión de venta de tickets en la
 * interfaz gráfica. Permite agregar, mostrar y actualizar información de la
 * venta de tickets. Utiliza la clase ContentTXTGestionVentaTkts para leer y
 * escribir datos en archivos de texto. Esta clase extiende de
 * javax.swing.JDialog.
 *
 * @author adrif
 */
public class JDGestionVentaTkts extends javax.swing.JDialog {

    ArrayList<GestionVentaTkts> ListaGestionVentaTkts = new ArrayList<>();
    ContentTXTGestionVentaTkts cont = new ContentTXTGestionVentaTkts();

    /**
     * Obtiene la lista de venta de tickets.
     *
     * @return La lista de venta de tickets.
     */
    public ArrayList<GestionVentaTkts> getListaGestionVentaTkts() {
        return ListaGestionVentaTkts;
    }

    /**
     * Crea una nueva instancia de JDGestionVentaTkts.
     *
     * @param parent El componente padre.
     * @param modal Indica si el diálogo es modal.
     */
    public JDGestionVentaTkts(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        actualizarVentas();
        mostrarVentas();
        actualizarCantidadVentas();
        cargarIdViajes();
        limpiarVentas();
        BtnActualizar.setEnabled(false);

    }

    /**
     * Carga los IDs de viajes en el ComboBox.
     */
    public void cargarIdViajes() {
        DefaultComboBoxModel<String> comboModel = new DefaultComboBoxModel<>();

        ContentTXTGestionViajes viajesLoader = new ContentTXTGestionViajes();
        ArrayList<VentaTkts> listaViajes = viajesLoader.getTxtGestionViajes();

        for (VentaTkts Viajes : listaViajes) {
            comboModel.addElement(String.valueOf(Viajes.getIdViaje()));
        }

        jComboBoxIdViaje.setModel(comboModel);
    }

    /**
     * Limpia los campos de entrada en la interfaz.
     */
    public void limpiarVentas() {
        TxtCantidadTkts.setText("");
        jComboBoxIdViaje.setSelectedItem(null);

        TxtCantidadTkts.setEnabled(true);
        jComboBoxIdViaje.setEnabled(true);
        BtnGuardar.setEnabled(true);
        BtnActualizar.setEnabled(false);

    }

    /**
     * Actualiza el contador de venta de tickets en la interfaz.
     */
    public void actualizarCantidadVentas() {

        LblCountGestionVentaTkts.setText(String.valueOf(ListaGestionVentaTkts.size()));

    }

    /**
     * Actualiza los datos de venta de tickets desde el archivo de texto.
     */
    public void actualizarVentas() {
        ListaGestionVentaTkts = cont.LeerData();

    }

    /**
     * Muestra los datos de venta de tickets en la tabla de la interfaz.
     */
    public void mostrarVentas() {

        DefaultTableModel mdl = new DefaultTableModel();
        mdl.addColumn("Id Viaje");
        mdl.addColumn("Cantidad tiquetes");

        for (GestionVentaTkts via : ListaGestionVentaTkts) {
            Object Curs[] = {
                via.getIdViaje(),
                via.getCantidadTkts(),};
            mdl.addRow(Curs);
        }
        TblGestionVentaTkts.setModel(mdl);
    }

    /**
     * Guarda los datos de venta de tickets en el archivo de texto.
     */
    public void guardarVentas() {
        cont.ingresarVentas(ListaGestionVentaTkts);
    }

    /**
     * Valida si ya existe una venta de tickets con el mismo ID de viaje.
     *
     * @param IdViaje El ID de viaje a validar.
     * @return `true` si ya existe una venta de tickets con el mismo ID, `false`
     * si no.
     */
    public boolean validarGestionVentaTkts(String IdViaje) {
        boolean r = false;
        for (int i = 0; i < ListaGestionVentaTkts.size(); i++) {
            if (IdViaje.equals(ListaGestionVentaTkts.get(i).getPlaca())) {
                r = true;
            }
        }

        return r;
    }

    /**
     * Método principal para ejecutar la ventana de gestión de venta de tickets.
     *
     * @param args Los argumentos de la línea de comandos.
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDGestionVentaTkts.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDGestionVentaTkts.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDGestionVentaTkts.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDGestionVentaTkts.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDGestionVentaTkts dialog = new JDGestionVentaTkts(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        BtnGuardar = new javax.swing.JButton();
        BtnActualizar = new javax.swing.JButton();
        BtnLimpiar = new javax.swing.JButton();
        BtnEliminar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        LblCountGestionVentaTkts = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jComboBoxIdViaje = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        TxtCantidadTkts = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TblGestionVentaTkts = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 153, 255), 3));
        jPanel3.setForeground(new java.awt.Color(204, 153, 255));
        jPanel3.setToolTipText("");

        BtnGuardar.setBackground(new java.awt.Color(204, 153, 255));
        BtnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        BtnGuardar.setText("Guardar");
        BtnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnGuardarMouseClicked(evt);
            }
        });
        BtnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnGuardarActionPerformed(evt);
            }
        });

        BtnActualizar.setBackground(new java.awt.Color(204, 153, 255));
        BtnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        BtnActualizar.setText("Actualizar");
        BtnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActualizarActionPerformed(evt);
            }
        });

        BtnLimpiar.setBackground(new java.awt.Color(204, 153, 255));
        BtnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        BtnLimpiar.setText("Limpiar");
        BtnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnLimpiarActionPerformed(evt);
            }
        });

        BtnEliminar.setBackground(new java.awt.Color(204, 0, 0));
        BtnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        BtnEliminar.setText("Eliminar");
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 153, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Cantidad Itinerarios");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel10.setOpaque(true);
        jLabel10.setVerifyInputWhenFocusTarget(false);

        LblCountGestionVentaTkts.setBackground(new java.awt.Color(255, 255, 255));
        LblCountGestionVentaTkts.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LblCountGestionVentaTkts.setForeground(new java.awt.Color(204, 153, 255));
        LblCountGestionVentaTkts.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LblCountGestionVentaTkts.setText("0");
        LblCountGestionVentaTkts.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        LblCountGestionVentaTkts.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        LblCountGestionVentaTkts.setOpaque(true);
        LblCountGestionVentaTkts.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(BtnActualizar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnGuardar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(LblCountGestionVentaTkts, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnGuardar)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BtnActualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnLimpiar)
                    .addComponent(LblCountGestionVentaTkts, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(BtnEliminar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 153, 255));
        jLabel3.setText("Id Viaje");
        jLabel3.setOpaque(true);

        jComboBoxIdViaje.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 153, 255));
        jLabel4.setText("Cantidad de tiquetes a vender");
        jLabel4.setOpaque(true);

        TxtCantidadTkts.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 153, 255));
        jLabel5.setText("Gestion Venta Tiquetes");
        jLabel5.setOpaque(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(TxtCantidadTkts, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jLabel4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBoxIdViaje, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(63, 63, 63))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxIdViaje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TxtCantidadTkts, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(107, 107, 107))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));

        TblGestionVentaTkts.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        TblGestionVentaTkts.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        TblGestionVentaTkts.setForeground(new java.awt.Color(0, 153, 153));
        TblGestionVentaTkts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TblGestionVentaTkts.setGridColor(new java.awt.Color(255, 255, 255));
        TblGestionVentaTkts.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TblGestionVentaTktsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TblGestionVentaTkts);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TblGestionVentaTktsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TblGestionVentaTktsMouseClicked

        int i = TblGestionVentaTkts.getSelectedRow();
        jComboBoxIdViaje.setSelectedItem(TblGestionVentaTkts.getValueAt(i, 0).toString());
        TxtCantidadTkts.setText(TblGestionVentaTkts.getValueAt(i, 1).toString());

        jComboBoxIdViaje.setEnabled(false);
        BtnGuardar.setEnabled(false);
        BtnActualizar.setEnabled(true);
    }//GEN-LAST:event_TblGestionVentaTktsMouseClicked

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed

        actualizarCantidadVentas();
        for (int i = 0; i < ListaGestionVentaTkts.size(); i++) {

            if (ListaGestionVentaTkts.get(i).getIdViaje() == Integer.parseInt(jComboBoxIdViaje.getSelectedItem().toString())) {
                int confirmado = JOptionPane.showConfirmDialog(
                        null, "¿Lo confirmas?");
                if (confirmado == 0) {
                    ListaGestionVentaTkts.remove(i);
                }

            }
        }
        guardarVentas();
        mostrarVentas();
        limpiarVentas();
        actualizarCantidadVentas();
        actualizarCantidadVentas();
        actualizarVentas();
    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void BtnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnLimpiarActionPerformed

        limpiarVentas();

    }//GEN-LAST:event_BtnLimpiarActionPerformed

    private void BtnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActualizarActionPerformed
        int selectedIdViaje = Integer.parseInt(jComboBoxIdViaje.getSelectedItem().toString());
        int cantidadTkts = Integer.parseInt(TxtCantidadTkts.getText());

        GestionVentaTkts ad = new GestionVentaTkts();
        ad.setIdViaje(selectedIdViaje);
        ad.setCantidadTkts(cantidadTkts);

        for (int i = 0; i < ListaGestionVentaTkts.size(); i++) {
            if (selectedIdViaje == ListaGestionVentaTkts.get(i).getIdViaje()) {
                ListaGestionVentaTkts.set(i, ad);
                break;
            }
        }

        guardarVentas();
        mostrarVentas();
        limpiarVentas();
        actualizarCantidadVentas();
        actualizarVentas();

    }//GEN-LAST:event_BtnActualizarActionPerformed

    private void BtnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnGuardarActionPerformed

    }//GEN-LAST:event_BtnGuardarActionPerformed

    private void BtnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnGuardarMouseClicked

        int selectedIdViaje = Integer.parseInt(jComboBoxIdViaje.getSelectedItem().toString());
        int cantidadTkts = Integer.parseInt(TxtCantidadTkts.getText());

        boolean viajeExiste = false;

        for (GestionVentaTkts ventaTkts : ListaGestionVentaTkts) {
            if (ventaTkts.getIdViaje() == selectedIdViaje) {
                ventaTkts.setCantidadTkts(ventaTkts.getCantidadTkts() + cantidadTkts);
                viajeExiste = true;
                limpiarVentas();

                guardarVentas();
                mostrarVentas();
                actualizarCantidadVentas();
                actualizarVentas();

                break;
            }
        }

        if (!viajeExiste) {
            GestionVentaTkts ad = new GestionVentaTkts();
            ad.setIdViaje(selectedIdViaje);
            ad.setCantidadTkts(cantidadTkts);
            ListaGestionVentaTkts.add(ad);
            limpiarVentas();

            guardarVentas();
            mostrarVentas();
            actualizarCantidadVentas();
            actualizarVentas();
        }


    }//GEN-LAST:event_BtnGuardarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnActualizar;
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnGuardar;
    private javax.swing.JButton BtnLimpiar;
    private javax.swing.JLabel LblCountGestionVentaTkts;
    private javax.swing.JTable TblGestionVentaTkts;
    private javax.swing.JTextField TxtCantidadTkts;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> jComboBoxIdViaje;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
