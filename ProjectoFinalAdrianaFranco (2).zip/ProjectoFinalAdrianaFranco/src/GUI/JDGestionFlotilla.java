/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package GUI;

import static GUI.JDGestionRutas.ListaGestionRutas;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ProyectoFinal.*;

/**
 * Esta clase representa la ventana de gestión de la flotilla de buses en la
 * interfaz gráfica. Permite agregar, mostrar y actualizar información de los
 * buses en la flotilla. Utiliza las clases ContentTXTGestionFlotilla y
 * ContentTXT para leer y escribir datos en archivos de texto. Esta clase
 * extiende de javax.swing.JDialog.
 *
 * @author adrif
 */
public class JDGestionFlotilla extends javax.swing.JDialog {

    static ArrayList<GestionFlotilla> ListaGestionFlotilla = new ArrayList<>();

    ContentTXTGestionFlotilla cont = new ContentTXTGestionFlotilla();
    //ContentTXT contP = new ContentTXT();

    /**
     * Crea una nueva instancia de JDGestionFlotilla.
     *
     * @param parent El componente padre.
     * @param modal Indica si el diálogo es modal.
     */
    public JDGestionFlotilla(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        actualizarFlotilla();
        mostrarFlotilla();
        actualizarCantidadFlotilla();
        BtnActualizar.setEnabled(false);

    }

    /**
     * Limpia los campos de entrada en la interfaz.
     */
    public void limpiarFlotilla() {
        TxtVidaUtil.setText("");
        TxtPlaca.setText("");
        TxtCantidadPasajeros.setText("");
        TxtNombreBus.setText("");
        TxtPlaca.setEnabled(true);
        BtnGuardar.setEnabled(true);
        BtnActualizar.setEnabled(false);

    }

    /**
     * Actualiza el contador de la flotilla en la interfaz.
     */
    public void actualizarCantidadFlotilla() {

        LblCountGestionFlotilla.setText(String.valueOf(ListaGestionFlotilla.size()));

    }

    /**
     * Actualiza los datos de la flotilla desde el archivo de texto.
     */
    public void actualizarFlotilla() {
        ListaGestionFlotilla = cont.getTxtGestionFlotilla();

    }

    /**
     * Muestra los datos de la flotilla en la tabla de la interfaz.
     */
    public void mostrarFlotilla() {

        DefaultTableModel mdl = new DefaultTableModel();
        mdl.addColumn("Placa");
        mdl.addColumn("Vida Util");
        mdl.addColumn("Cantidad de pasajeros");
        mdl.addColumn("Nombre del Bus");

        for (GestionFlotilla cur : ListaGestionFlotilla) {
            Object Curs[] = {
                cur.getPlaca(),
                cur.getVidaUtil(),
                cur.getCantidadPasajeros(),
                cur.getNombreBus(),};
            mdl.addRow(Curs);
        }
        TblGestionFlotilla.setModel(mdl);
    }

    /**
     * Guarda los datos de la flotilla en el archivo de texto.
     */
    public void guardarFlotilla() {
        cont.ingresarFlotilla(ListaGestionFlotilla);
    }

    /**
     * Valida si un bus con la placa especificada ya existe en la lista.
     *
     * @param placa La placa del bus a validar.
     * @return `true` si el bus ya existe, `false` si no.
     */
    public boolean validarGestionFlotilla(String placa) {
        boolean r = false;
        for (int i = 0; i < ListaGestionFlotilla.size(); i++) {
            if (ListaGestionFlotilla.get(i).getPlaca() == Integer.parseInt(TxtPlaca.getText())){
                r = true;
            }
        }
        return r;
    }

    /**
     * Método principal para ejecutar la ventana de gestión de la flotilla de
     * buses.
     *
     * @param args Los argumentos de la línea de comandos.
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDGestionFlotilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDGestionFlotilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDGestionFlotilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDGestionFlotilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDGestionFlotilla dialog = new JDGestionFlotilla(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TxtVidaUtil = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        TxtPlaca = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        TxtCantidadPasajeros = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        BtnGuardar = new javax.swing.JButton();
        BtnActualizar = new javax.swing.JButton();
        BtnLimpiar = new javax.swing.JButton();
        BtnEliminar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        LblCountGestionFlotilla = new javax.swing.JLabel();
        TxtNombreBus = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TblGestionFlotilla = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 153, 255));
        jLabel1.setText("Vida Util");
        jLabel1.setOpaque(true);

        TxtVidaUtil.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        TxtVidaUtil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtVidaUtilActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 153, 255));
        jLabel2.setText("Placa");
        jLabel2.setOpaque(true);

        TxtPlaca.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 153, 255));
        jLabel6.setText("Cantidad Pasajeros");
        jLabel6.setOpaque(true);

        TxtCantidadPasajeros.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        TxtCantidadPasajeros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtCantidadPasajerosActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 153, 255));
        jLabel7.setText("Nombre Bus");
        jLabel7.setOpaque(true);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 153, 255), 3));
        jPanel3.setForeground(new java.awt.Color(0, 153, 153));
        jPanel3.setToolTipText("");

        BtnGuardar.setBackground(new java.awt.Color(204, 153, 255));
        BtnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        BtnGuardar.setText("Guardar");
        BtnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnGuardarActionPerformed(evt);
            }
        });

        BtnActualizar.setBackground(new java.awt.Color(204, 153, 255));
        BtnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        BtnActualizar.setText("Actualizar");
        BtnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActualizarActionPerformed(evt);
            }
        });

        BtnLimpiar.setBackground(new java.awt.Color(204, 153, 255));
        BtnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        BtnLimpiar.setText("Limpiar");
        BtnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnLimpiarActionPerformed(evt);
            }
        });

        BtnEliminar.setBackground(new java.awt.Color(204, 0, 0));
        BtnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        BtnEliminar.setText("Eliminar");
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 153, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Cantidad Buses");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel10.setOpaque(true);
        jLabel10.setVerifyInputWhenFocusTarget(false);

        LblCountGestionFlotilla.setBackground(new java.awt.Color(255, 255, 255));
        LblCountGestionFlotilla.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LblCountGestionFlotilla.setForeground(new java.awt.Color(204, 153, 255));
        LblCountGestionFlotilla.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LblCountGestionFlotilla.setText("0");
        LblCountGestionFlotilla.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        LblCountGestionFlotilla.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        LblCountGestionFlotilla.setOpaque(true);
        LblCountGestionFlotilla.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(BtnActualizar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnGuardar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(LblCountGestionFlotilla, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnGuardar)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BtnActualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnLimpiar)
                    .addComponent(LblCountGestionFlotilla, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(BtnEliminar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TxtNombreBus.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        TxtNombreBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtNombreBusActionPerformed(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 153, 255));
        jLabel8.setText("Gestion Flotilla");
        jLabel8.setOpaque(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(TxtNombreBus, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel6))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(TxtVidaUtil, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                                        .addComponent(TxtPlaca)
                                        .addComponent(TxtCantidadPasajeros, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtVidaUtil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtCantidadPasajeros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtNombreBus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));

        TblGestionFlotilla.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        TblGestionFlotilla.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        TblGestionFlotilla.setForeground(new java.awt.Color(0, 153, 153));
        TblGestionFlotilla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TblGestionFlotilla.setGridColor(new java.awt.Color(255, 255, 255));
        TblGestionFlotilla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TblGestionFlotillaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TblGestionFlotilla);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 474, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnGuardarActionPerformed

        GestionFlotilla Pr = new GestionFlotilla();
        Pr.setPlaca(Integer.parseInt(TxtPlaca.getText()));
        Pr.setNombreBus(String.valueOf(TxtNombreBus.getText()));
        Pr.setVidaUtil(Integer.parseInt(TxtVidaUtil.getText()));
        Pr.setCantidadPasajeros(Integer.parseInt(TxtCantidadPasajeros.getText()));
        
        if (validarGestionFlotilla(TxtPlaca.getText()) == false) {
            ListaGestionFlotilla.add(Pr);
            guardarFlotilla();
            mostrarFlotilla();
            actualizarCantidadFlotilla();
            limpiarFlotilla();
        } else {
            JOptionPane.showMessageDialog(null, "El bus ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BtnGuardarActionPerformed

    private void BtnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnLimpiarActionPerformed

        limpiarFlotilla();


    }//GEN-LAST:event_BtnLimpiarActionPerformed

    private void BtnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActualizarActionPerformed

        GestionFlotilla Pr = new GestionFlotilla();
        Pr.setNombreBus(String.valueOf(TxtNombreBus.getText()));
        Pr.setCantidadPasajeros(Integer.parseInt(TxtCantidadPasajeros.getText()));
        Pr.setVidaUtil(Integer.parseInt(TxtVidaUtil.getText()));
        Pr.setPlaca(Integer.parseInt(TxtPlaca.getText()));

        for (int i = 0; i < ListaGestionFlotilla.size(); i++) {

            if (ListaGestionFlotilla.get(i).getPlaca() == Integer.parseInt(TxtPlaca.getText())) {
                ListaGestionFlotilla.set(i, Pr);
            }
        }

        guardarFlotilla();
        mostrarFlotilla();
        limpiarFlotilla();


    }//GEN-LAST:event_BtnActualizarActionPerformed

    private void TblGestionFlotillaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TblGestionFlotillaMouseClicked

        int i = TblGestionFlotilla.getSelectedRow();
        TxtPlaca.setText(TblGestionFlotilla.getValueAt(i, 0).toString());
        TxtVidaUtil.setText(TblGestionFlotilla.getValueAt(i, 1).toString());
        TxtCantidadPasajeros.setText(TblGestionFlotilla.getValueAt(i, 2).toString());
        TxtNombreBus.setText(TblGestionFlotilla.getValueAt(i, 3).toString());
        TxtPlaca.setEnabled(false);
        BtnGuardar.setEnabled(false);
        BtnActualizar.setEnabled(true);
    }//GEN-LAST:event_TblGestionFlotillaMouseClicked

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed

        actualizarCantidadFlotilla();
        for (int i = 0; i < ListaGestionFlotilla.size(); i++) {

            if (ListaGestionFlotilla.get(i).getPlaca() == Integer.parseInt(TxtPlaca.getText())) {
                int confirmado = JOptionPane.showConfirmDialog(
                        null, "¿Lo confirmas?");
                if (confirmado == 0) {
                    ListaGestionFlotilla.remove(i);
                }

            }
        }
        guardarFlotilla();
        mostrarFlotilla();
        limpiarFlotilla();
        actualizarCantidadFlotilla();

    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void TxtCantidadPasajerosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtCantidadPasajerosActionPerformed

    }//GEN-LAST:event_TxtCantidadPasajerosActionPerformed

    private void TxtNombreBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtNombreBusActionPerformed

    }//GEN-LAST:event_TxtNombreBusActionPerformed

    private void TxtVidaUtilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtVidaUtilActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtVidaUtilActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnActualizar;
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnGuardar;
    private javax.swing.JButton BtnLimpiar;
    private javax.swing.JLabel LblCountGestionFlotilla;
    private javax.swing.JTable TblGestionFlotilla;
    private javax.swing.JTextField TxtCantidadPasajeros;
    private javax.swing.JTextField TxtNombreBus;
    private javax.swing.JTextField TxtPlaca;
    private javax.swing.JTextField TxtVidaUtil;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
