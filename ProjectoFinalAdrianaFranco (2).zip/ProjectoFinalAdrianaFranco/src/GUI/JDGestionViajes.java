/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package GUI;

import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ProyectoFinal.*;
import ProyectoFinal.ContentTXTGestionChoferes;

/**
 * Esta clase representa la ventana de gestión de viajes en la interfaz gráfica.
 * Permite agregar, mostrar y actualizar información de los viajes. Utiliza la
 * clase ContentTXTGestionViajes para leer y escribir datos en archivos de
 * texto. Esta clase extiende de javax.swing.JDialog.
 *
 * @author adrif
 */
public class JDGestionViajes extends javax.swing.JDialog {

    static ArrayList<VentaTkts> ListaGestionViajes = new ArrayList<>();
    ContentTXTGestionViajes cont = new ContentTXTGestionViajes();

    /**
     * Obtiene la lista de viajes gestionados.
     *
     * @return La lista de viajes gestionados.
     */
    public ArrayList<VentaTkts> getListaGestionViajes() {
        return ListaGestionViajes;
    }

    /**
     * Crea una nueva instancia de JDGestionViajes.
     *
     * @param parent El componente padre.
     * @param modal Indica si el diálogo es modal.
     */
    public JDGestionViajes(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        actualizarViajes();
        mostrarViajes();
        actualizarCantidadViajes();
        cargarPlacas();
        cargarCedulas();
        cargarIdRuta();
        limpiarViajes();
        BtnActualizar.setEnabled(false);

        DefaultTableModel tblModel = new DefaultTableModel();
        tblModel.addColumn("Id Viaje");
        tblModel.addColumn("Placa");
        tblModel.addColumn("Cedula");
        tblModel.addColumn("Id Ruta");
        tblModel.addColumn("Fecha");
        tblModel.addColumn("Hora");

        TblGestionViajes.setModel(tblModel); 
        mostrarDatosEnTabla(); 
    }

    /**
     * Muestra los datos de los viajes en la tabla de la interfaz.
     */
    public void mostrarDatosEnTabla() {
        ContentTXTGestionViajes txtGestionViajes = new ContentTXTGestionViajes();
        ArrayList<VentaTkts> listaViajes = txtGestionViajes.getTxtGestionViajes();

        DefaultTableModel tblModel = (DefaultTableModel) TblGestionViajes.getModel();
        tblModel.setRowCount(0);

        for (VentaTkts viaje : listaViajes) {
            Object[] rowData = {
                viaje.getIdViaje(),
                viaje.getPlaca(),
                viaje.getCedula(),
                viaje.getIdRuta(),
                viaje.getFecha(),
                viaje.getHora()
            };
            tblModel.addRow(rowData);
        }
    }

    /**
     * Carga las placas de la flotilla en el ComboBox.
     */
    public void cargarPlacas() {
        DefaultComboBoxModel<String> comboModel = new DefaultComboBoxModel<>();

        ContentTXTGestionFlotilla flotillaLoader = new ContentTXTGestionFlotilla();
        ArrayList<GestionFlotilla> listaFlotilla = flotillaLoader.getTxtGestionFlotilla();

        for (GestionFlotilla flotilla : listaFlotilla) {
            comboModel.addElement(String.valueOf(flotilla.getPlaca()));
        }

        jComboBoxPlaca.setModel(comboModel);
    }

    /**
     * Carga las cédulas de los choferes en el ComboBox.
     */
    public void cargarCedulas() {
        DefaultComboBoxModel<String> comboModel = new DefaultComboBoxModel<>();

        ContentTXTGestionChoferes choferesLoader = new ContentTXTGestionChoferes();
        ArrayList<GestionChoferes> listaChoferes = choferesLoader.getTxtGestionChoferes();

        for (GestionChoferes choferes : listaChoferes) {
            comboModel.addElement(String.valueOf(choferes.getCedula()));
        }

        jComboBoxCedula.setModel(comboModel);

    }

    /**
     * Carga los IDs de las rutas en el ComboBox.
     */
    public void cargarIdRuta() {
        DefaultComboBoxModel<String> comboModel = new DefaultComboBoxModel<>();

        ContentTXTGestionRutas rutasLoader = new ContentTXTGestionRutas();
        ArrayList<GestionRutas> listaRutas = rutasLoader.getTxtGestionRutas();

        for (GestionRutas ruta : listaRutas) {
            comboModel.addElement(String.valueOf(ruta.getIdRuta()));
        }

        jComboBoxIdRuta.setModel(comboModel);

    }

    /**
     * Limpia los campos de entrada en la interfaz.
     */
    public void limpiarViajes() {
        TxtIdViaje.setText("");
        jComboBoxPlaca.setSelectedItem(null);
        jComboBoxCedula.setSelectedItem(null);
        jComboBoxIdRuta.setSelectedItem(null);
        jComboBoxDia.setSelectedItem(null);
        jComboBoxMes.setSelectedItem(null);
        jComboBoxAnio.setSelectedItem(null);
        jComboBoxHora.setSelectedItem(null);
        jComboBoxMin.setSelectedItem(null);

        TxtIdViaje.setEnabled(true);
        BtnGuardar.setEnabled(true);
        BtnActualizar.setEnabled(false);

    }

    /**
     * Actualiza el contador de venta de tickets en la interfaz.
     */
    public void actualizarCantidadViajes() {

        LblCountGestionViajes.setText(String.valueOf(ListaGestionViajes.size()));

    }

    /**
     * Actualiza los datos de venta de tickets desde el archivo de texto.
     */
    public void actualizarViajes() {
        ListaGestionViajes = cont.getTxtGestionViajes();

    }

    /**
     * Muestra los datos de venta de tickets en la tabla de la interfaz.
     */
    public void mostrarViajes() {

        DefaultTableModel mdl = new DefaultTableModel();
        mdl.addColumn("Id Viaje");
        mdl.addColumn("Placa");
        mdl.addColumn("Cedula ");
        mdl.addColumn("Id Ruta");
        mdl.addColumn("Fecha");
        mdl.addColumn("Hora");

        for (VentaTkts via : ListaGestionViajes) {
            Object Curs[] = {
                via.getIdViaje(),
                via.getPlaca(),
                via.getCedula(),
                via.getIdRuta(),
                via.getFecha(),
                via.getHora(),};
            mdl.addRow(Curs);
        }
        TblGestionViajes.setModel(mdl);
    }

    /**
     * Guarda los datos de venta de tickets en el archivo de texto.
     */
    public void guardarViajes() {
        cont.ingresarViajes(ListaGestionViajes);
    }

    /**
     * Valida si ya existe una venta de tickets con el mismo ID de viaje.
     *
     * @param IdViaje El ID de placa a validar.
     * @return `true` si ya existe una venta de tickets con el mismo ID, `false`
     * si no.
     */
    public boolean validarGestionViajes(int IdViaje) {
        for (int i = 0; i < ListaGestionViajes.size(); i++) {
            if (IdViaje == ListaGestionViajes.get(i).getIdViaje()) {
                return true; // Si encontramos el ID, retornamos true
            }
        }
        return false; // Si no encontramos el ID, retornamos false
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDGestionViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDGestionViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDGestionViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDGestionViajes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDGestionViajes dialog = new JDGestionViajes(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        TxtIdViaje = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jComboBoxCedula = new javax.swing.JComboBox<>();
        jComboBoxIdRuta = new javax.swing.JComboBox<>();
        jComboBoxDia = new javax.swing.JComboBox<>();
        jComboBoxMes = new javax.swing.JComboBox<>();
        jComboBoxAnio = new javax.swing.JComboBox<>();
        jComboBoxPlaca = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBoxHora = new javax.swing.JComboBox<>();
        jComboBoxMin = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        BtnGuardar = new javax.swing.JButton();
        BtnActualizar = new javax.swing.JButton();
        BtnLimpiar = new javax.swing.JButton();
        BtnEliminar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        LblCountGestionViajes = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TblGestionViajes = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 153, 255));
        jLabel1.setText("Cedula");
        jLabel1.setOpaque(true);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 153, 255));
        jLabel2.setText("Placa");
        jLabel2.setOpaque(true);

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 153, 255));
        jLabel6.setText("Dia");
        jLabel6.setOpaque(true);

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 153, 255));
        jLabel7.setText("Mes");
        jLabel7.setOpaque(true);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 153, 255));
        jLabel3.setText("Id Viaje");
        jLabel3.setOpaque(true);

        TxtIdViaje.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 153, 255));
        jLabel8.setText("ID Ruta");
        jLabel8.setOpaque(true);

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 153, 255));
        jLabel9.setText("Año");
        jLabel9.setOpaque(true);

        jComboBoxCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCedulaActionPerformed(evt);
            }
        });

        jComboBoxIdRuta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBoxDia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jComboBoxDia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxDiaActionPerformed(evt);
            }
        });

        jComboBoxMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Setiembre", "Octubre", "Noviembre", "Diciembre" }));
        jComboBoxMes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxMesActionPerformed(evt);
            }
        });

        jComboBoxAnio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2022", "2023", "2024", "2025", "2026", " " }));
        jComboBoxAnio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxAnioActionPerformed(evt);
            }
        });

        jComboBoxPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPlacaActionPerformed(evt);
            }
        });

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(204, 153, 255));
        jLabel11.setText("Hora");
        jLabel11.setOpaque(true);

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 153, 255));
        jLabel12.setText("Min");
        jLabel12.setOpaque(true);

        jComboBoxHora.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24" }));
        jComboBoxHora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxHoraActionPerformed(evt);
            }
        });

        jComboBoxMin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "05", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55" }));
        jComboBoxMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxMinActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 153, 255), 3));
        jPanel3.setForeground(new java.awt.Color(204, 153, 255));
        jPanel3.setToolTipText("");

        BtnGuardar.setBackground(new java.awt.Color(204, 153, 255));
        BtnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        BtnGuardar.setText("Guardar");
        BtnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnGuardarMouseClicked(evt);
            }
        });
        BtnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnGuardarActionPerformed(evt);
            }
        });

        BtnActualizar.setBackground(new java.awt.Color(204, 153, 255));
        BtnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        BtnActualizar.setText("Actualizar");
        BtnActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnActualizarMouseClicked(evt);
            }
        });
        BtnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnActualizarActionPerformed(evt);
            }
        });

        BtnLimpiar.setBackground(new java.awt.Color(204, 153, 255));
        BtnLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        BtnLimpiar.setText("Limpiar");
        BtnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnLimpiarActionPerformed(evt);
            }
        });

        BtnEliminar.setBackground(new java.awt.Color(204, 0, 0));
        BtnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        BtnEliminar.setText("Eliminar");
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 153, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Cantidad Itinerarios");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel10.setOpaque(true);
        jLabel10.setVerifyInputWhenFocusTarget(false);

        LblCountGestionViajes.setBackground(new java.awt.Color(255, 255, 255));
        LblCountGestionViajes.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LblCountGestionViajes.setForeground(new java.awt.Color(204, 153, 255));
        LblCountGestionViajes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LblCountGestionViajes.setText("0");
        LblCountGestionViajes.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        LblCountGestionViajes.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        LblCountGestionViajes.setOpaque(true);
        LblCountGestionViajes.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(BtnActualizar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnGuardar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnLimpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BtnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(LblCountGestionViajes, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnGuardar)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BtnActualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnLimpiar)
                    .addComponent(LblCountGestionViajes, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(BtnEliminar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 153, 255));
        jLabel4.setText("Gestion Viajes");
        jLabel4.setOpaque(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxDia, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBoxHora, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBoxMin, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jComboBoxMes, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jComboBoxIdRuta, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jComboBoxCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jComboBoxPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(26, 26, 26)
                                                .addComponent(TxtIdViaje, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(42, 42, 42)
                                        .addComponent(jComboBoxAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(jLabel4)))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtIdViaje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxIdRuta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));

        TblGestionViajes.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        TblGestionViajes.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        TblGestionViajes.setForeground(new java.awt.Color(0, 153, 153));
        TblGestionViajes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TblGestionViajes.setGridColor(new java.awt.Color(255, 255, 255));
        TblGestionViajes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TblGestionViajesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TblGestionViajes);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(7, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TblGestionViajesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TblGestionViajesMouseClicked

        int i = TblGestionViajes.getSelectedRow();
        TxtIdViaje.setText(TblGestionViajes.getValueAt(i, 0).toString());
        jComboBoxPlaca.setSelectedItem(TblGestionViajes.getValueAt(i, 1).toString());
        jComboBoxCedula.setSelectedItem(TblGestionViajes.getValueAt(i, 2).toString());
        jComboBoxIdRuta.setSelectedItem(TblGestionViajes.getValueAt(i, 3).toString());
        String fechaGuardada = TblGestionViajes.getValueAt(i, 4).toString();
        String[] partesFecha = fechaGuardada.split("/");
        jComboBoxDia.setSelectedItem(partesFecha[0]);
        jComboBoxMes.setSelectedItem(partesFecha[1]);
        jComboBoxAnio.setSelectedItem(partesFecha[2]);
        String horaGuardada = TblGestionViajes.getValueAt(i, 5).toString();
        String[] partesHora = horaGuardada.split(":");
        jComboBoxHora.setSelectedItem(partesHora[0]);
        jComboBoxMin.setSelectedItem(partesHora[1]);

        TxtIdViaje.setEnabled(false);
        BtnGuardar.setEnabled(false);
        BtnActualizar.setEnabled(true);
    }//GEN-LAST:event_TblGestionViajesMouseClicked

    private void jComboBoxMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxMinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxMinActionPerformed

    private void jComboBoxHoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxHoraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxHoraActionPerformed

    private void jComboBoxPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPlacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxPlacaActionPerformed

    private void jComboBoxAnioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxAnioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxAnioActionPerformed

    private void jComboBoxMesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxMesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxMesActionPerformed

    private void jComboBoxDiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxDiaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxDiaActionPerformed

    private void jComboBoxCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCedulaActionPerformed

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed

        actualizarCantidadViajes();
        for (int i = 0; i < ListaGestionViajes.size(); i++) {

            if (ListaGestionViajes.get(i).getIdViaje() == Integer.parseInt(TxtIdViaje.getText())) {
                int confirmado = JOptionPane.showConfirmDialog(
                        null, "¿Lo confirmas?");
                if (confirmado == 0) {
                    ListaGestionViajes.remove(i);
                }

            }
        }
        guardarViajes();
        mostrarViajes();
        limpiarViajes();
        actualizarCantidadViajes();
    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void BtnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnLimpiarActionPerformed

        limpiarViajes();

    }//GEN-LAST:event_BtnLimpiarActionPerformed

    private void BtnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnActualizarActionPerformed
        String dia = jComboBoxDia.getSelectedItem().toString();
        String mes = jComboBoxMes.getSelectedItem().toString();
        String anio = jComboBoxAnio.getSelectedItem().toString();
        String fechaCompleta = dia + "/" + mes + "/" + anio;

        String hora = jComboBoxHora.getSelectedItem().toString();
        String min = jComboBoxMin.getSelectedItem().toString();
        String horaCompleta = hora + ":" + min;

        VentaTkts Vi = new VentaTkts();
        Vi.setIdViaje(Integer.parseInt(TxtIdViaje.getText()));
        Vi.setPlaca(String.valueOf(jComboBoxPlaca.getSelectedItem().toString()));
        Vi.setCedula(String.valueOf(jComboBoxCedula.getSelectedItem().toString()));
        Vi.setIdRuta(String.valueOf(jComboBoxIdRuta.getSelectedItem().toString()));
        Vi.setFecha(fechaCompleta);
        Vi.setHora(horaCompleta);

        for (int i = 0; i < ListaGestionViajes.size(); i++) {

            if (ListaGestionViajes.get(i).getIdViaje() == Integer.parseInt(TxtIdViaje.getText())) {
                ListaGestionViajes.set(i, Vi);
            }
        }

        guardarViajes();
        mostrarViajes();
        actualizarCantidadViajes();
        limpiarViajes();
        TxtIdViaje.setEnabled(true);
        BtnGuardar.setEnabled(false);
    }//GEN-LAST:event_BtnActualizarActionPerformed

    private void BtnActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnActualizarMouseClicked

    }//GEN-LAST:event_BtnActualizarMouseClicked

    private void BtnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnGuardarActionPerformed

    }//GEN-LAST:event_BtnGuardarActionPerformed

    private void BtnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnGuardarMouseClicked

        String dia = jComboBoxDia.getSelectedItem().toString();
        String mes = jComboBoxMes.getSelectedItem().toString();
        String anio = jComboBoxAnio.getSelectedItem().toString();
        String fechaCompleta = dia + "/" + mes + "/" + anio;

        String hora = jComboBoxHora.getSelectedItem().toString();
        String min = jComboBoxMin.getSelectedItem().toString();
        String horaCompleta = hora + ":" + min;

        VentaTkts Vi = new VentaTkts();
        Vi.setIdViaje(Integer.parseInt(TxtIdViaje.getText()));
        Vi.setPlaca(String.valueOf(jComboBoxPlaca.getSelectedItem().toString()));
        Vi.setCedula(String.valueOf(jComboBoxCedula.getSelectedItem().toString()));
        Vi.setIdRuta(String.valueOf(jComboBoxIdRuta.getSelectedItem().toString()));
        Vi.setFecha(fechaCompleta);
        Vi.setHora(horaCompleta);

        boolean viajeExistente = validarGestionViajes(Integer.parseInt(TxtIdViaje.getText()));

        if (viajeExistente) {
            JOptionPane.showMessageDialog(null, "El viaje ya existe. Por favor, elige otro Viaje.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        } else {
            boolean viajeEncontrado = false;

            for (int i = 0; i < ListaGestionViajes.size(); i++) {
                if (ListaGestionViajes.get(i).getIdViaje() == Integer.parseInt(TxtIdViaje.getText())) {
                    ListaGestionViajes.set(i, Vi);
                    viajeEncontrado = true;
                    break; // Ya encontramos el viaje, no es necesario seguir buscando
                }
            }

            if (!viajeEncontrado) {
                ListaGestionViajes.add(Vi);
                guardarViajes();
                mostrarViajes();
                actualizarCantidadViajes();
                limpiarViajes();
            }
        }
        limpiarViajes();
    }//GEN-LAST:event_BtnGuardarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnActualizar;
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnGuardar;
    private javax.swing.JButton BtnLimpiar;
    private javax.swing.JLabel LblCountGestionViajes;
    private javax.swing.JTable TblGestionViajes;
    private javax.swing.JTextField TxtIdViaje;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> jComboBoxAnio;
    private javax.swing.JComboBox<String> jComboBoxCedula;
    private javax.swing.JComboBox<String> jComboBoxDia;
    private javax.swing.JComboBox<String> jComboBoxHora;
    private javax.swing.JComboBox<String> jComboBoxIdRuta;
    private javax.swing.JComboBox<String> jComboBoxMes;
    private javax.swing.JComboBox<String> jComboBoxMin;
    private javax.swing.JComboBox<String> jComboBoxPlaca;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
