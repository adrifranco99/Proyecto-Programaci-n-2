/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

import GUI.JFLogin;


/**
 *
 * @author adrif
 * Punto de entrada principal para la aplicación GUI.
 * Inicia la interfaz de inicio de sesión.
 */
public class MainGUI {

    /**
     * Método principal que inicia la aplicación.
     * Crea una instancia de JFLogin y la hace visible.
     *
     * @param args Los argumentos de la línea de comandos (no se utilizan).
     */
    public static void main(String[] args) {
        // Crear una instancia de la ventana de inicio de sesión
        JFLogin login = new JFLogin();
        
        // Hacer visible la ventana de inicio de sesión
        login.setVisible(true);
    }

}
