/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

/**
 *
 * @author adrif
 */
/**
 * Clase que representa la gestión de ventas de tiquetes. Hereda de la clase
 * VentaTkts y agrega la cantidad de tiquetes vendidos.
 */
public class GestionVentaTkts extends VentaTkts {

    public int cantidadTkts;

    /**
     * Constructor parametrizado para crear una instancia de GestionVentaTkts.
     *
     * @param IdViaje El ID del viaje al que se relaciona la venta.
     * @param placa La placa del vehículo asociado al viaje.
     * @param cedula La cédula del cliente que realiza la compra.
     * @param IdRuta El ID de la ruta del viaje.
     * @param fecha La fecha de la venta.
     * @param hora La hora de la venta.
     * @param cantidadTkts La cantidad de tiquetes vendidos.
     */
    public GestionVentaTkts(int IdViaje, String placa, String cedula, String IdRuta, String fecha, String hora, int cantidadTkts) {
        super(IdViaje, placa, cedula, IdRuta, fecha, hora);
        this.cantidadTkts = this.cantidadTkts;
    }

    /**
     * Constructor por defecto que inicializa la cantidad de tiquetes en 0.
     */
    public GestionVentaTkts() {
        this.cantidadTkts = 0;

    }

    // Métodos getters y setters para acceder y modificar los atributos.
    public int getCantidadTkts() {
        return cantidadTkts;
    }

    public void setCantidadTkts(int cantidadTkts) {
        this.cantidadTkts = cantidadTkts;
    }

}
