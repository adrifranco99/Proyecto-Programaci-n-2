/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

/**
 * Esta clase representa a los administradores del sistema. Contiene información
 * sobre el usuario, contraseña y correo electrónico del administrador. Los
 * métodos getter y setter permiten acceder y modificar estos atributos.
 *
 * @author adrif
 */
public class Administradores {

    private String usuario;
    private String password;
    private String correo;

    /**
     * Constructor que inicializa los atributos de un administrador.
     *
     * @param usuario El nombre de usuario del administrador.
     * @param password La contraseña del administrador.
     * @param correo El correo electrónico del administrador.
     */
    public Administradores(String usuario, String password, String correo) {
        this.usuario = usuario;
        this.password = password;
        this.correo = correo;
    }

    /**
     * Constructor sin argumentos que inicializa los atributos en valores
     * predeterminados.
     */
    public Administradores() {
        this.usuario = "";
        this.password = "";
        this.correo = "";
    }

    /**
     * Métodos getters y setters para acceder y modificar los atributos.
     */
    public String getUsuario() {
        return usuario;
    }
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }

}
