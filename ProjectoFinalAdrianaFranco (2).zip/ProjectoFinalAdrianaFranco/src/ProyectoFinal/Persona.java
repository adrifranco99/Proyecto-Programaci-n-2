/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

/**
 *
 * @author adrif
 */
/**
 * Clase abstracta que representa a una persona. Contiene atributos y métodos
 * para gestionar información común de las personas.
 */
public abstract class Persona {

    /**
     * Atributo que guarda la cedula
     */
    protected String cedula;

    /**
     * Atributo que guarda el nombre de la persona
     */
    protected String nombre;
    /**
     * Atributo que guarda el apellido paterno
     */
    protected String apellido1;
    /**
     * Atributo que guarda el apellido materno
     */
    protected String apellido2;
    /**
     * Atributo que guarda el numero de telefono
     */
    protected int numTel;

    /**
     * Constructor para inicializar una instancia de Persona con valores.
     *
     * @param cedula La cédula de la persona.
     * @param nombre El nombre de la persona.
     * @param apellido1 El primer apellido de la persona.
     * @param apellido2 El segundo apellido de la persona.
     * @param numTel El número de teléfono de la persona.
     */
    public Persona(String cedula, String nombre, String apellido1, String apellido2, int numTel) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.numTel = numTel;
    }

    /**
     * Constructor por defecto que inicializa una instancia de Persona con
     * valores predeterminados.
     */
    public Persona() {
        this.cedula = "";
        this.nombre = "";
        this.apellido1 = "";
        this.apellido2 = "";
        this.numTel = 0;
    }

    // Métodos getters y setters para acceder y modificar los atributos.
    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public int getNumTel() {
        return numTel;
    }

    public void setNumTel(int numTel) {
        this.numTel = numTel;
    }

    /**
     * Método abstracto para ingresar los datos de la persona. Las clases que
     * hereden de Persona deben implementar este método.
     */
    public abstract void ingresarDatos();

    /**
     * Método abstracto para mostrar los datos de la persona. Las clases que
     * hereden de Persona deben implementar este método.
     */
    public abstract void mostrarDatos();

}
