/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author adrif
 */
/**
 * Clase para gestionar la lectura y escritura de datos relacionados con las
 * rutas.
 */
public class ContentTXTGestionRutas {

    // Nombre del archivo de texto que almacena los datos de las rutas
    String txtLocPersona = "GestionRutas.txt";

    /**
     * Agrega los datos de las rutas a un archivo de texto.
     *
     * @param lista La lista de objetos GestionRutas a guardar.
     */
    public void ingresarRutas(ArrayList lista) {
        FileWriter fileWriter = null;

        try {

            fileWriter = new FileWriter(txtLocPersona);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            for (GestionRutas GRutas : (ArrayList<GestionRutas>) lista) {
                bufferedWriter.write(GRutas.getIdRuta() + "," + GRutas.getLugarSalida() + ","
                        + "" + GRutas.getLugarLlegada() + "," + GRutas.getRuta() + "," + GRutas.getTiempoEstimado() + "\n");
            }
            bufferedWriter.close();
            System.out.println("El archivo rutas a sido creado exitosamente");
        } catch (Exception e) {
            System.out.println("Error al guardar los datos de las rutas");
        } finally {
            if (fileWriter != null) {
                try {
                    fileWriter.close();
                } catch (Exception e) {
                    System.out.println("Error al cerrar la conexion rutas");
                }
            }
        }

    }

    /**
     * Lee los datos de las rutas desde un archivo de texto y los almacena en
     * una lista.
     *
     * @return Una lista de objetos GestionRutas con los datos de las rutas.
     */
    public ArrayList getTxtGestionRutas() {
        ArrayList<GestionRutas> ListaTxt = new ArrayList<>();
        File file = new File(txtLocPersona);

        Scanner scanner;

        try {

            scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                Scanner delimitar = new Scanner(linea);
                GestionRutas a = new GestionRutas();
                delimitar.useDelimiter("\\s*,\\s*");
                a.setIdRuta(Integer.parseInt(delimitar.next()));
                a.setLugarSalida(String.valueOf(delimitar.next().toString()));
                a.setLugarLlegada(String.valueOf(delimitar.next().toString()));
                a.setRuta(String.valueOf(delimitar.next().toString()));
                a.setTiempoEstimado(Integer.parseInt(delimitar.next()));

                ListaTxt.add(a);
            }

            scanner.close();

        } catch (Exception e) {
            System.out.println("error al traer los datos rutas");

        }

        return ListaTxt;
    }

}
