/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author adrif
 */
/**
 * Clase para gestionar la lectura y escritura de datos relacionados con las
 * ventas de tiquetes.
 */
public class ContentTXTGestionVentaTkts {

    // Ruta del archivo de texto que almacena los datos de las ventas de tiquetes
    String txtLocVentas = "GestionVentaTkts.txt";

    /**
     * Agrega los datos de las ventas de tiquetes a un archivo de texto.
     *
     * @param lista La lista de objetos GestionVentaTkts a guardar.
     */
    public void ingresarVentas(ArrayList lista) {
        FileWriter fileWriter = null;

        try {
            fileWriter = new FileWriter(txtLocVentas);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            for (GestionVentaTkts ventaTkts : (ArrayList<GestionVentaTkts>) lista) {
                bufferedWriter.write(ventaTkts.getIdViaje() + "," + ventaTkts.getCantidadTkts() + "\n");
            }
            bufferedWriter.close();
            System.out.println("El archivo ventas ha sido actualizado exitosamente");
        } catch (Exception e) {
            System.out.println("Se ha actualizado la cantidad para el ID de viaje seleccionado"
                    + "");
        } finally {
            if (fileWriter != null) {
                try {
                    fileWriter.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * Lee los datos de las ventas de tiquetes desde un archivo de texto y los
     * almacena en una lista.
     *
     * @return Una lista de objetos GestionVentaTkts con los datos de las ventas
     * de tiquetes.
     */
    public ArrayList LeerData() {
        File file = new File(txtLocVentas);

        ArrayList<GestionVentaTkts> listaGestionVentaTkts = new ArrayList<>();

        Scanner scanner;

        try {

            scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                Scanner delimitar = new Scanner(linea);
                GestionVentaTkts a = new GestionVentaTkts();
                delimitar.useDelimiter("\\s*,\\s*");
                a.setIdViaje(Integer.parseInt(delimitar.next()));
                a.setCantidadTkts(Integer.parseInt(delimitar.next()));
                listaGestionVentaTkts.add(a);
            }
            scanner.close();

        } catch (Exception e) {
            System.out.println("Error al traer los datos de las ventas111.txt ");
        }

        return listaGestionVentaTkts;
    }
}
