/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;


/**
 *
 * @author adrif
 */
/**
 * Clase que representa una venta de tiquetes. Contiene información sobre el
 * viaje, placa del bus, cédula del comprador, ruta, fecha y hora de la venta.
 */
public class VentaTkts {

    public int IdViaje;
    public String placa;
    public String cedula;
    public String IdRuta;
    public String fecha;
    public String hora;

    /**
     * Constructor para inicializar una instancia de VentaTkts con valores.
     *
     * @param IdViaje El ID del viaje al que se relaciona la venta.
     * @param placa La placa del bus asociada a la venta.
     * @param cedula La cédula del comprador de los tiquetes.
     * @param IdRuta El ID de la ruta relacionada a la venta.
     * @param fecha La fecha en que se realizó la venta.
     * @param hora La hora en que se realizó la venta.
     */
    public VentaTkts(int IdViaje, String placa, String cedula, String IdRuta, String fecha, String hora) {
        this.IdViaje = IdViaje;
        this.placa = placa;
        this.IdRuta = IdRuta;
        this.fecha = fecha;
        this.hora = hora;

    }

    /**
     * Constructor por defecto que inicializa una instancia de VentaTkts con
     * valores predeterminados.
     */
    public VentaTkts() {
        this.IdViaje = 0;
        this.placa = "";
        this.cedula = "";
        this.IdRuta = "";
        this.fecha = "";
        this.hora = "";

    }

    
    // Métodos getters y setters para acceder y modificar los atributos.
    public int getIdViaje() {
        return IdViaje;
    }
    public void setIdViaje(int IdViaje) {
        this.IdViaje = IdViaje;
    }
    public String getPlaca() {
        return placa;
    }
    public void setPlaca(String placa) {
        this.placa = placa;
    }
    public String getCedula() {
        return cedula;
    }
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
    public String getIdRuta() {
        return IdRuta;
    }
    public void setIdRuta(String IdRuta) {
        this.IdRuta = IdRuta;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getHora() {
        return hora;
    }
    public void setHora(String hora) {
        this.hora = hora;
    }

}
