/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author adrif
 */
/**
 * Clase para gestionar la lectura y escritura de datos de administradores.
 */
public class ContentTXTAdministradores {

    // Ruta del archivo de texto que almacena los datos de administradores
    String txtLocAdmin = "Administrador.txt";

    /**
     * Guarda los datos de administradores en un archivo de texto.
     *
     * @param lista La lista de objetos Administradores a guardar.
     */
    public void ingresarAdmin(ArrayList<Administradores> lista) {
        FileWriter fileWriter = null;

        try {
            fileWriter = new FileWriter(txtLocAdmin);
            BufferedWriter buffer = new BufferedWriter(fileWriter);

            for (Administradores a : lista) {
                buffer.write(a.getUsuario() + "," + a.getCorreo() + "," + a.getPassword() + "\n");
            }
            buffer.close();

            System.out.println("Los datos se han guardado admin exitosamente");

        } catch (Exception e) {
            System.out.println("Error al guardar los datos admin");
        } finally {
            try {

                if (fileWriter != null) {
                    fileWriter.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la conexion admin");
            }

        }

    }

    /**
     * Lee los datos de administradores desde un archivo de texto y los almacena
     * en una lista.
     *
     * @return Una lista de objetos Administradores con los datos de
     * administradores.
     */
    public ArrayList getTxtAdministrador() {
        File file = new File(txtLocAdmin);
        ArrayList<Administradores> ListaTxt = new ArrayList<>();

        Scanner scanner;

        try {

            scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();

                Scanner delimitar = new Scanner(linea);
                Administradores a = new Administradores();
                delimitar.useDelimiter("\\s*,\\s*");

                if (delimitar.hasNext()) {
                    a.setUsuario(String.valueOf(delimitar.next().toString()));
                }
                if (delimitar.hasNext()) {
                    a.setCorreo(String.valueOf(delimitar.next().toString()));
                }
                if (delimitar.hasNext()) {
                    a.setPassword(String.valueOf(delimitar.next()));
                }

                ListaTxt.add(a);
            }

            scanner.close();

        } catch (Exception e) {
            System.out.println("error al traer los datos admin1" + e.getMessage());
            e.printStackTrace();

        }

        return ListaTxt;
    }

}
