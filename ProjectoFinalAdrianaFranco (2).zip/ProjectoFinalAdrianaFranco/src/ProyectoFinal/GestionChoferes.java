/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProyectoFinal;

/**
 *
 * @author adrif
 */
/**
 * Clase que representa la gestión de choferes.
 */
public class GestionChoferes extends Persona {

    private int annosExperiencia;

    /**
     * Constructor parametrizado para crear una instancia de GestionChoferes.
     *
     * @param cedula La cédula del chofer.
     * @param nombre El nombre del chofer.
     * @param apellido1 El primer apellido del chofer.
     * @param apellido2 El segundo apellido del chofer.
     * @param numTel El número de teléfono del chofer.
     * @param annosExperiencia Los años de experiencia del chofer.
     */
    public GestionChoferes(String cedula, String nombre, String apellido1, String apellido2, int numTel, int annosExperiencia) {
        super(cedula, nombre, apellido1, apellido2, numTel);
        this.annosExperiencia = this.annosExperiencia;
    }

    /**
     * Constructor por defecto que inicializa los atributos en valores por
     * defecto.
     */
    public GestionChoferes() {
        this.annosExperiencia = 0;
    }

    // Métodos getters y setters para acceder y modificar los atributos.
    public int getAnnosExperiencia() {
        return annosExperiencia;
    }
    public void setAnnosExperiencia(int annosExperiencia) {
        this.annosExperiencia = annosExperiencia;
    }
    
    
    @Override
    public void ingresarDatos() {
        // Implementación para ingresar los datos del chofer.

    }

    @Override
    public void mostrarDatos() {
        // Implementación para mostrar los datos del chofer.

    }

}
