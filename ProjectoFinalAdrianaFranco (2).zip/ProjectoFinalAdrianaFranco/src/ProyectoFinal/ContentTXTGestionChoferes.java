/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author adrif
 */
/**
 * Clase para gestionar la lectura y escritura de datos relacionados con los
 * choferes.
 */
public class ContentTXTGestionChoferes {

    // Ruta del archivo de texto que almacena los datos de los choferes
    String txtLocGestionChoferes = "GestionChoferes.txt";

    /**
     * Guarda los datos de los choferes en un archivo de texto.
     *
     * @param lista La lista de objetos GestionChoferes a guardar.
     */
    public void ingresarChoferes(ArrayList lista) {
        FileWriter fileWriter = null;

        try {

            fileWriter = new FileWriter(txtLocGestionChoferes);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            for (GestionChoferes GC : (ArrayList<GestionChoferes>) lista) {
                bufferedWriter.write(GC.getCedula() + "," + GC.getNombre() + ","
                        + "" + GC.getApellido1() + "," + GC.getApellido2() + ","
                        + "" + GC.getNumTel() + "," + GC.getAnnosExperiencia() + "\n");
            }
            bufferedWriter.close();
            System.out.println("El archivo a sido creado chofer exitosamente");
        } catch (Exception e) {
            System.out.println("Error al guardar los datos de chofer el en txt");
        } finally {
            if (fileWriter != null) {
                try {
                    fileWriter.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * Lee los datos de los choferes desde un archivo de texto y los almacena en
     * una lista.
     *
     * @return Una lista de objetos GestionChoferes con los datos de los
     * choferes.
     */
    public ArrayList getTxtGestionChoferes() {
        ArrayList<GestionChoferes> ListaTxt = new ArrayList<>();
        File file = new File(txtLocGestionChoferes);

        Scanner scanner;

        try {

            scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();

                Scanner delimitar = new Scanner(linea);
                GestionChoferes gc = new GestionChoferes();
                delimitar.useDelimiter("\\s*,\\s*");

                if (delimitar.hasNext()) {
                    gc.setCedula(String.valueOf(delimitar.next().toString()));
                }
                if (delimitar.hasNext()) {
                    gc.setNombre(String.valueOf(delimitar.next().toString()));
                }
                if (delimitar.hasNext()) {
                    gc.setApellido1(String.valueOf(delimitar.next().toString()));
                }
                if (delimitar.hasNext()) {
                    gc.setApellido2(String.valueOf(delimitar.next().toString()));
                }
                if (delimitar.hasNext()) {
                    gc.setNumTel(Integer.parseInt(delimitar.next().toString()));
                }
                if (delimitar.hasNext()) {
                    gc.setAnnosExperiencia(Integer.parseInt(delimitar.next().toString()));
                }

                ListaTxt.add(gc);
            }

            scanner.close();

        } catch (Exception e) {
            System.out.println("error al traer los datos admin1" + e.getMessage());
            e.printStackTrace();

        }

        return ListaTxt;
    }

}
