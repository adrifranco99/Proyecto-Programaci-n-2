/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author adrif
 */
/**
 * Clase para gestionar la lectura y escritura de datos relacionados con los
 * viajes.
 */
public class ContentTXTGestionViajes {

    // Ruta del archivo de texto que almacena los datos de los viajes
    String txtLocViajes = "GestionViajes.txt";

    /**
     * Guarda los datos de los viajes en un archivo de texto.
     *
     * @param lista La lista de objetos VentaTkts a guardar.
     */
    public void ingresarViajes(ArrayList<VentaTkts> lista) {
        FileWriter fileWriter = null;

        try {
            fileWriter = new FileWriter(txtLocViajes);
            BufferedWriter buffer = new BufferedWriter(fileWriter);

            for (VentaTkts a : lista) {
                buffer.write(a.getIdViaje() + "," + a.getPlaca() + "," + a.getCedula() + "," + a.getIdRuta() + "," + a.getFecha() + "," + a.getHora() + "\n");
            }
            buffer.close();

            System.out.println("Los datos viajes se han guardado exitosamente");

        } catch (Exception e) {
            System.out.println("Error al guardar los datos del viaje");
        } finally {
            try {

                if (fileWriter != null) {
                    fileWriter.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la conexion viajes");
            }

        }

    }

    /**
     * Lee los datos de los viajes desde un archivo de texto y los almacena en
     * una lista.
     *
     * @return Una lista de objetos VentaTkts con los datos de los viajes.
     */
    public ArrayList getTxtGestionViajes() {
        ArrayList<VentaTkts> ListaTxt = new ArrayList<>();
        File file = new File(txtLocViajes);

        Scanner scanner;

        try {

            scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                Scanner delimitar = new Scanner(linea);
                VentaTkts a = new VentaTkts();
                delimitar.useDelimiter("\\s*,\\s*");
                a.setIdViaje(Integer.parseInt(delimitar.next()));
                a.setPlaca(String.valueOf(delimitar.next().toString()));
                a.setCedula(String.valueOf(delimitar.next().toString()));
                a.setIdRuta(String.valueOf(delimitar.next().toString()));
                a.setFecha(String.valueOf(delimitar.next().toString()));
                a.setHora(String.valueOf(delimitar.next().toString()));

                ListaTxt.add(a);
            }

            scanner.close();

        } catch (Exception e) {
            System.out.println("error al traer los datos viajes");

        }

        return ListaTxt;
    }

}
