/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author adrif
 */
/**
 * Clase para gestionar la lectura y escritura de datos relacionados con la
 * flotilla de buses.
 */
public class ContentTXTGestionFlotilla {

    // Ruta del archivo de texto que almacena los datos de la flotilla
    String txtLocFlotilla = "GestionFlotilla.txt";

    /**
     * Guarda los datos de la flotilla en un archivo de texto.
     *
     * @param lista La lista de objetos GestionFlotilla a guardar.
     */
    public void ingresarFlotilla(ArrayList<GestionFlotilla> lista) {
        FileWriter fileWriter = null;

        try {
            fileWriter = new FileWriter(txtLocFlotilla);
            BufferedWriter buffer = new BufferedWriter(fileWriter);

            for (GestionFlotilla a : lista) {
                buffer.write(a.getPlaca() + "," + a.getCantidadPasajeros() + "," + a.getNombreBus() + "," + a.getVidaUtil() + "\n");
            }
            buffer.close();

            System.out.println("Los datos se han guardado flotilla exitosamente");

        } catch (Exception e) {
            System.out.println("Error al guardar los datos de flotilla");
        } finally {
            try {

                if (fileWriter != null) {
                    fileWriter.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la conexion flotilla");
            }

        }

    }

    /**
     * Lee los datos de la flotilla desde un archivo de texto y los almacena en
     * una lista.
     *
     * @return Una lista de objetos GestionFlotilla con los datos de la
     * flotilla.
     */
    public ArrayList getTxtGestionFlotilla() {
        ArrayList<GestionFlotilla> ListaTxt = new ArrayList<>();
        File file = new File(txtLocFlotilla);

        Scanner scanner;

        try {

            scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                Scanner delimitar = new Scanner(linea);
                GestionFlotilla a = new GestionFlotilla();
                delimitar.useDelimiter("\\s*,\\s*");
                a.setPlaca(Integer.parseInt(delimitar.next()));
                a.setCantidadPasajeros(Integer.parseInt(delimitar.next()));
                a.setNombreBus(String.valueOf(delimitar.next().toString()));
                a.setVidaUtil(Integer.parseInt(delimitar.next()));

                ListaTxt.add(a);
            }

            scanner.close();

        } catch (Exception e) {
            System.out.println("error al traer los datos flotilla");

        }

        return ListaTxt;
    }

}
