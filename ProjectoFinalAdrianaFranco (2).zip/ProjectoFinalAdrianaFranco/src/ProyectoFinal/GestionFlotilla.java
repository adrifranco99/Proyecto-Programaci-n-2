/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

/**
 *
 * @author adrif
 */
/**
 * Clase que representa la gestión de la flotilla de buses.
 */
public class GestionFlotilla {

    public int placa;
    private int cantidadPasajeros;
    private String nombreBus;
    private int vidaUtil;

    /**
     * Constructor parametrizado para crear una instancia de GestionFlotilla.
     *
     * @param placa El número de placa del bus.
     * @param cantidadPasajeros La cantidad de pasajeros que puede transportar
     * el bus.
     * @param nombreBus El nombre del bus.
     * @param vidaUtil La vida útil del bus.
     */
    public GestionFlotilla(int placa, int cantidadPasajeros, String nombreBus, int vidaUtil) {
        this.placa = placa;
        this.cantidadPasajeros = cantidadPasajeros;
        this.nombreBus = nombreBus;
        this.vidaUtil = vidaUtil;
    }

    /**
     * Constructor por defecto que inicializa los atributos en valores por
     * defecto.
     */
    public GestionFlotilla() {
        this.placa = 0;
        this.cantidadPasajeros = 0;
        this.nombreBus = "";
        this.vidaUtil = 0;
    }

    // Métodos getters y setters para acceder y modificar los atributos.
    public int getPlaca() {
        return placa;
    }

    public void setPlaca(int placa) {
        this.placa = placa;
    }

    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

    public void setCantidadPasajeros(int cantidadPasajeros) {
        this.cantidadPasajeros = cantidadPasajeros;
    }

    public String getNombreBus() {
        return nombreBus;
    }

    public void setNombreBus(String nombreBus) {
        this.nombreBus = nombreBus;
    }

    public int getVidaUtil() {
        return vidaUtil;
    }

    public void setVidaUtil(int vidaUtil) {
        this.vidaUtil = vidaUtil;
    }

}
