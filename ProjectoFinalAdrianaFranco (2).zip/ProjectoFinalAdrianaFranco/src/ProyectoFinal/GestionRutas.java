/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyectoFinal;

/**
 *
 * @author adrif
 */
/**
 * Clase que representa la gestión de rutas para los viajes.
 */
public class GestionRutas {

    public int IdRuta;
    private String lugarSalida;
    private String lugarLlegada;
    private String ruta;
    private int tiempoEstimado;

    /**
     * Constructor parametrizado para crear una instancia de GestionRutas.
     *
     * @param IdRuta El ID de la ruta.
     * @param lugarSalida El lugar de salida de la ruta.
     * @param lugarLlegada El lugar de llegada de la ruta.
     * @param ruta La descripción de la ruta.
     * @param tiempoEstimado El tiempo estimado de la ruta.
     */
    public GestionRutas(int IdRuta, String lugarSalida, String lugarLlegada, String ruta, int tiempoEstimado) {
        this.IdRuta = IdRuta;
        this.lugarSalida = lugarSalida;
        this.lugarLlegada = lugarLlegada;
        this.ruta = ruta;
        this.tiempoEstimado = tiempoEstimado;

    }

    /**
     * Constructor por defecto que inicializa los atributos en valores por
     * defecto.
     */
    public GestionRutas() {
        this.IdRuta = 0;
        this.lugarSalida = "";
        this.lugarLlegada = "";
        this.ruta = "";
        this.tiempoEstimado = 0;
    }

    // Métodos getters y setters para acceder y modificar los atributos.
    public int getIdRuta() {
        return IdRuta;
    }

    public void setIdRuta(int IdRuta) {
        this.IdRuta = IdRuta;
    }

    public String getLugarSalida() {
        return lugarSalida;
    }

    public void setLugarSalida(String lugarSalida) {
        this.lugarSalida = lugarSalida;
    }

    public String getLugarLlegada() {
        return lugarLlegada;
    }

    public void setLugarLlegada(String lugarLlegada) {
        this.lugarLlegada = lugarLlegada;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public int getTiempoEstimado() {
        return tiempoEstimado;
    }

    public void setTiempoEstimado(int tiempoEstimado) {
        this.tiempoEstimado = tiempoEstimado;
    }

}
